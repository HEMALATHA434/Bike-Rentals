<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'bikes');
$f = $_SESSION["sfueltype"];
$b = $_SESSION["sbrand"];
$s = "SELECT * FROM vehicle where vehicle_brand = '$b' and fuel_type= '$f' ";
$r = mysqli_query($conn, $s);

?>

<?php
if(isset($_POST["submit1"]))
{
  header('Location:TermsConditions.html');
}
?>
<html>

<head>
    <link rel="stylesheet" href="search_bike.css">
    <style>
      .button {
        background-color: #4CAF70;
	      color: white;
        text-align:center;
        padding:5px 20px 5px 20px;
        font-size:16px;
        cursor:pointer;
      }
    </style>
</head>

<body>

<?php
if(mysqli_num_rows($r)>0){
    while($row = mysqli_fetch_array($r)){
?>
<div class="movie-card">

  <div class="container">
  
    <img src="<?php echo $row['bike_img']?>" height="300px" width="300px">
        
    <span class="hero">
            
      <span class="details">
      
        <div class="title1"><center><?php echo $row['vehicle_brand'] ?></center></div>

        <div class="title2"><center><?php echo $row['vehicle_name'] ?></center></div>    
        
    </span> <!-- end details -->
      
    </span> <!-- end hero -->
    
    <div class="description">
      
      <div class="column1">
      <!-- <a id="g" href="booking.php?id=<?php echo $row["id"]; ?>"><button type="submit"> Book  </button></a>
      </div> end column1 -->
      
      <div class="column2">
        
        <label>Overview: </label> <br><?php echo $row['vehicle_overview']?>
        <br>
        <label>Price: </label> <?php echo $row['price_per_day']?>
        <br>
        <label>Fuel Type: </label> <?php echo $row['fuel_type']?>
        <br>
        <label>Model Year: </label> <?php echo $row['model_year']?>
        <br>
        <label>Seating Capacity: </label> <?php echo $row['seating_capacity']?>
        <br>
        <label>Ground Clearence: </label> <?php echo $row['ground_clearence']?>
        <br>
        <label>Color: </label> <?php echo $row['color']?>
        <br>
        <label>Engine Capacity: </label> <?php echo $row['engine_capacity']?>
        <br>
        <label>Fuel Tank Capcity: </label> <?php echo $row['fuel_tank_capacity']?>
        <br>
        <label>Registration Date: </label> <?php echo $row['reg_date']?>

        <br><br>

       <form name="form1" actions="" method="post">
        <input type="submit" class="button" name="submit1" value="Next">
    </form>
        
        
      </div> <!-- end column2 -->
    </div> <!-- end description -->
    
   
  </div> <!-- end container -->
</div> <!-- end movie-card -->

<?php
    }
}
?>
</body>

</html>