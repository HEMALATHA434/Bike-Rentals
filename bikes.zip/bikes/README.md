# Online_Bike_Rentals
It is my mini-project done on my 3rd year of Btech. <br>Built a user-friendly website where a user can book bikes of their favourite brand for rent per day and  <br>Admin can manage all the bookings, registered users and the queries asked by the customers. <br>  FRONTEND - HTML5, CSS3    ||    BACKEND - PHP   ||     DATABASE - Mysql     ||    SERVER - Xampp
